const express = require('express');
const empmodel = require('../model/model');

const addform = async(req,resp)=>{
    resp.render("addemp");
}

const addemp =async(req,resp)=>{
    try {
        const data = new empmodel({
            name:req.body.name,
            sal: req.body.sal,
            dept:req.body.dept
        })
        await data.save();
        resp.redirect("/showemp")
    } catch (error) {
        console.log(error);
        
    }
}

const showemp = async(req,resp)=>{
    try {
        const data = await empmodel.find();
        resp.render("showemp",{data})
    } catch (error) {
        console.log(error);
        
    }
}

const editform = async(req,resp)=>{
    try {
        const data = await empmodel.findById(req.params.id)
        resp.render("editemp",{data});
    } catch (error) {
        console.log(error);
        
    }
}
const editemp = async(req,resp)=>{
    try {
        const data = await empmodel.findByIdAndUpdate(req.params.id,req.body,{new:true});
        resp.redirect("/showemp");
    } catch (error) {
       console.log(error);
        
    }
}

const deleteemp = async(req,resp)=>{
    try {
        const data = await empmodel.findByIdAndDelete(req.params.id);
        resp.redirect("/showemp");
    } catch (error) {
        console.log(error);
        
    }
}
module.exports={addemp,addform,showemp,editemp,editform,deleteemp}







//  for session 

// const userModel = require('../model/userModel');
// const bcryptjs = require ('bcryptjs');

// const register = async(req,resp)=>{
//     try {
//         const {uname ,email ,password} = req.body;
//         const hashpassword = await bcryptjs.hash(password,10);
//         console.log(hashpassword);
//         await userModel.create({uname,email,password:hashpassword});
//         resp.redirect("/login");
//     } catch (error) {
//         console.log(error);
//     }
// }

// const login =async(req,resp)=>{
//     try {
//         const {uname,password}=req.body;
//         const user = await userModel.findOne({uname});
//         if (user && await bcryptjs.compare(password,user.password)) {
//             req.session.name =uname;
//             resp.redirect("/dashboard");
//         } else {
//             resp.redirect("/login");
//         }
//     } catch (error) {
//         console.log(error);
//     }
// }

// const dashboard = async(req,resp)=>{
//     if (!req.session.name) {
//         resp.redirect("/login");
//     } else {
//         resp.render("dashboard",{data:req.session.name});
//     }
// }

// const logout = async(req,resp)=>{
//     req.session.destroy(()=>{
//         resp.redirect("/login");
//     })
// }
// module.exports = {register ,login ,dashboard,logout};