const express = require('express');
const  {addemp,addform,showemp,editemp,editform,deleteemp}= require('../controller/controller');
const router = express.Router();

router.get("/addemp",addform);
router.post("/addemp",addemp);
router.get("/showemp",showemp);
router.get("/editemp/:id",editform);
router.patch("/editemp/:id",editemp);
router.delete("/deleteemp/:id",deleteemp);

module.exports = router;



//for session route 
// const express = require('express');
// const {register,login,dashboard,logout} = require ("../controller/userController")
// const router = express.Router();

// router.get("/",(req,resp)=>{
//     resp.render("register");
// });
// router.post("/register",register)

// router.get("/login",(req,resp)=>{
//     resp.render("login");
// });
// router.post("/login",login);

// router.get("/dashboard",dashboard);
// router.get("/logout",logout);

// module.exports = router;