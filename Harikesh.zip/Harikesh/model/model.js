const mongoose = require('mongoose');

const empschema = mongoose.Schema({
    name:{
        type:String,
        unique:true,
        required:true
    },
    sal:{
        type:Number,
        min:10000,
        required:true
    },
    dept:{
        type:String,
        enum:["HR","ACC","IT","SALES"],
        required:true
    }
},{timestamps:true});
const empmodel = mongoose.model("emp",empschema);
module.exports ={empmodel};