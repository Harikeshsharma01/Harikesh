const express = require('express');
const {connectDB} = require("./db");
const router = require ('./route/route');
const method_override = require("method-override");
//const session = require('express-session');

connectDB();
const app = express();

// //for session
// app.use(session({
//     secret:"abc",
//     resave:false,
//     saveUninitialized:false
// }))
// //

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(method_override("_method"));

app.set("view engine","ejs");
app.use("/",router);

app.listen(4500,()=>{
    console.log("running...");
    
})